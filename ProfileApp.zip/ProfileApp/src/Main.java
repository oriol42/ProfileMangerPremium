import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Logger;

public class Main {
    private static final Logger LOGGER = Logger.getLogger(Main.class.getName());
    private static final Color PRIMARY_GRADIENT_START = new Color(25, 118, 210);
    private static final Color PRIMARY_GRADIENT_END = new Color(3, 169, 244);
    private static final Color BACKGROUND_COLOR = new Color(245, 247, 250);

    public static void main(String[] args) {
        setModernLookAndFeel();
        SwingUtilities.invokeLater(() -> {
            showSplashScreen(() -> {
                showWelcomeMessage(() -> {
                    AppUI app = new AppUI();
                    app.setVisible(true);
                    centerWindow(app);
                });
            });
        });
    }

    private static void setModernLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            UIManager.put("ProgressBar.foreground", PRIMARY_GRADIENT_START);
            UIManager.put("Label.font", new Font("Segoe UI", Font.PLAIN, 14));
        } catch (Exception e) {
            LOGGER.warning("Failed to set look and feel: " + e.getMessage());
        }
    }

    private static void showSplashScreen(Runnable onCloseAction) {
        JWindow splash = new JWindow();
        splash.setSize(600, 400);
        centerWindow(splash);

        JPanel content = new JPanel(new BorderLayout()) {
            private static final long serialVersionUID = 1L;
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gradient = new GradientPaint(
                        0, 0, PRIMARY_GRADIENT_START,
                        getWidth(), getHeight(), PRIMARY_GRADIENT_END);
                g2d.setPaint(gradient);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
            }
        };
        content.setBorder(new EmptyBorder(40, 40, 40, 40));
        content.setOpaque(false);

        JLabel logo = new JLabel(new ImageIcon(createPlaceholderLogo(1.0f)));
        logo.setHorizontalAlignment(JLabel.CENTER);
        logo.setBorder(new EmptyBorder(0, 0, 40, 0));

        Timer pulseTimer = new Timer();
        pulseTimer.scheduleAtFixedRate(new TimerTask() {
            float scale = 1.0f;
            boolean growing = true;

            @Override
            public void run() {
                scale += growing ? 0.02f : -0.02f;
                if (scale >= 1.1f) growing = false;
                if (scale <= 0.9f) growing = true;
                logo.setIcon(new ImageIcon(createPlaceholderLogo(scale)));
            }
        }, 0, 50);

        JLabel title = new JLabel("Profile Manager Premium", JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 36));
        title.setForeground(Color.WHITE);
        title.setBorder(new EmptyBorder(0, 0, 30, 0));

        JProgressBar progressBar = new JProgressBar();
        progressBar.setIndeterminate(true);
        progressBar.setBorder(new EmptyBorder(20, 60, 20, 60));
        progressBar.setForeground(new Color(255, 255, 255, 200));
        progressBar.setBackground(new Color(255, 255, 255, 40));
        progressBar.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 100), 1, true));

        content.add(logo, BorderLayout.NORTH);
        content.add(title, BorderLayout.CENTER);
        content.add(progressBar, BorderLayout.SOUTH);

        splash.setContentPane(content);
        animateWindow(splash, pulseTimer, onCloseAction);
    }

    private static void showWelcomeMessage(Runnable onCloseAction) {
        JWindow welcome = new JWindow();
        welcome.setSize(500, 300);
        centerWindow(welcome);

        JPanel content = new JPanel(new BorderLayout()) {
            private static final long serialVersionUID = 1L;
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(BACKGROUND_COLOR);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
            }
        };
        content.setBorder(new EmptyBorder(30, 30, 30, 30));
        content.setOpaque(false);

        JLabel messageLabel = new JLabel("Bienvenue dans Profile Manager !", JLabel.CENTER);
        messageLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        messageLabel.setForeground(PRIMARY_GRADIENT_START);

        Timer zoomTimer = new Timer();
        zoomTimer.scheduleAtFixedRate(new TimerTask() {
            float scale = 0.5f;

            @Override
            public void run() {
                scale += 0.05f;
                if (scale >= 1.0f) {
                    scale = 1.0f;
                    zoomTimer.cancel();
                }
                messageLabel.setFont(new Font("Segoe UI", Font.BOLD, (int) (24 * scale)));
            }
        }, 0, 50);

        content.add(messageLabel, BorderLayout.CENTER);

        welcome.setContentPane(content);
        animateWindow(welcome, zoomTimer, onCloseAction);
    }

    private static void animateWindow(JWindow window, Timer animationTimer, Runnable onCloseAction) {
        window.setOpacity(0.0f);
        window.setVisible(true);

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            float opacity = 0.0f;

            @Override
            public void run() {
                opacity += 0.05f;
                if (opacity >= 1.0f) {
                    opacity = 1.0f;
                    timer.cancel();
                    new Timer().schedule(new TimerTask() {
                        @Override
                        public void run() {
                            Timer fadeOutTimer = new Timer();
                            fadeOutTimer.scheduleAtFixedRate(new TimerTask() {
                                float outOpacity = 1.0f;

                                @Override
                                public void run() {
                                    outOpacity -= 0.05f;
                                    outOpacity = Math.max(0.0f, outOpacity);
                                    window.setOpacity(outOpacity);
                                    if (outOpacity <= 0.0f) {
                                        window.dispose();
                                        animationTimer.cancel();
                                        SwingUtilities.invokeLater(onCloseAction);
                                        fadeOutTimer.cancel();
                                    }
                                }
                            }, 0, 50);
                        }
                    }, 2000);
                }
                window.setOpacity(opacity);
            }
        }, 0, 50);
    }

    private static Image createPlaceholderLogo(float scale) {
        int baseSize = 120;
        int scaledSize = (int) (baseSize * scale);
        BufferedImage img = new BufferedImage(scaledSize, scaledSize, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = img.createGraphics();

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(new Color(255, 255, 255, 200));
        g2d.fillOval(0, 0, scaledSize, scaledSize);

        g2d.setColor(PRIMARY_GRADIENT_START);
        g2d.setFont(new Font("Segoe UI", Font.BOLD, (int) (48 * scale)));

        String text = "PM";
        FontMetrics fm = g2d.getFontMetrics();
        int x = (scaledSize - fm.stringWidth(text)) / 2;
        int y = ((scaledSize - fm.getHeight()) / 2) + fm.getAscent();

        g2d.drawString(text, x, y);
        g2d.dispose();
        return img;
    }

    private static void centerWindow(Window window) {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(
                (screenSize.width - window.getWidth()) / 2,
                (screenSize.height - window.getHeight()) / 2
        );
    }
}