import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Profile implements Serializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private String photoPath;
    private String nom;
    private String prenom;
    private LocalDate naissance;
    private int age;
    private String nationalite;
    private LocalDate derniereVisiteMedicale;
    private String email;
    private String telephone;
    private String github;
    private String linkedin;
    private String bio;
    private int anneesExperience;
    private String niveau;
    private boolean disponible;
    private List<String> competences = new ArrayList<>();
    private List<String> langues = new ArrayList<>();

    public Profile() {}

    public Profile(String nom, String prenom, String email) {
        this.nom = sanitize(nom);
        this.prenom = sanitize(prenom);
        this.email = sanitize(email);
    }

    private String sanitize(String input) {
        return input != null ? input.trim() : "";
    }

    // Getters & Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = sanitize(photoPath);
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = sanitize(nom);
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = sanitize(prenom);
    }

    public LocalDate getNaissance() {
        return naissance;
    }

    public void setNaissance(LocalDate naissance) {
        this.naissance = naissance;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = Math.max(0, age);
    }

    public String getNationalite() {
        return nationalite;
    }

    public void setNationalite(String nationalite) {
        this.nationalite = sanitize(nationalite);
    }

    public LocalDate getDerniereVisiteMedicale() {
        return derniereVisiteMedicale;
    }

    public void setDerniereVisiteMedicale(LocalDate derniereVisiteMedicale) {
        this.derniereVisiteMedicale = derniereVisiteMedicale;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = sanitize(email);
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = sanitize(telephone);
    }

    public String getGithub() {
        return github;
    }

    public void setGithub(String github) {
        this.github = sanitize(github);
    }

    public String getLinkedin() {
        return linkedin;
    }

    public void setLinkedin(String linkedin) {
        this.linkedin = sanitize(linkedin);
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = sanitize(bio);
    }

    public int getAnneesExperience() {
        return anneesExperience;
    }

    public void setAnneesExperience(int anneesExperience) {
        this.anneesExperience = Math.max(0, anneesExperience);
    }

    public String getNiveau() {
        return niveau;
    }

    public void setNiveau(String niveau) {
        this.niveau = sanitize(niveau);
        if (this.niveau.isEmpty()) this.niveau = "Junior";
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public List<String> getCompetences() {
        return competences;
    }

    public void setCompetences(List<String> competences) {
        this.competences = competences != null ? new ArrayList<>(competences) : new ArrayList<>();
    }

    public List<String> getLangues() {
        return langues;
    }

    public void setLangues(List<String> langues) {
        this.langues = langues != null ? new ArrayList<>(langues) : new ArrayList<>();
    }
}