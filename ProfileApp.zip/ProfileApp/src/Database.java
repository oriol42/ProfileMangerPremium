import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class Database {
    private static final Logger LOGGER = Logger.getLogger(Database.class.getName());
    private static final String DB_URL = "jdbc:sqlite:profiles.db";
    
    private Connection conn;

    public Database() {
        connect();
        initDatabase();
    }

    private void connect() {
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection(DB_URL);
        } catch (Exception e) {
            LOGGER.severe("Database connection failed: " + e.getMessage());
            throw new RuntimeException("Failed to connect to database", e);
        }
    }

    private void initDatabase() {
        String pragmaSql = "PRAGMA foreign_keys = ON";
        String[] createSqls = {
            "CREATE TABLE IF NOT EXISTS profils (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "photo TEXT," +
                "nom TEXT NOT NULL," +
                "prenom TEXT NOT NULL," +
                "naissance DATE," +
                "age INTEGER," +
                "nationalite TEXT," +
                "derniere_visite_medicale DATE," +
                "email TEXT UNIQUE," +
                "telephone TEXT," +
                "github TEXT," +
                "linkedin TEXT," +
                "bio TEXT," +
                "annees_experience INTEGER," +
                "niveau TEXT CHECK(niveau IN ('Junior', 'Intermédiaire', 'Senior'))," +
                "disponible BOOLEAN" +
            ")",
            "CREATE TABLE IF NOT EXISTS competences (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "profil_id INTEGER," +
                "technologie TEXT," +
                "niveau INTEGER CHECK(niveau BETWEEN 1 AND 5)," +
                "FOREIGN KEY(profil_id) REFERENCES profils(id) ON DELETE CASCADE" +
            ")",
            "CREATE TABLE IF NOT EXISTS langues (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "profil_id INTEGER," +
                "langue TEXT," +
                "niveau TEXT," +
                "FOREIGN KEY(profil_id) REFERENCES profils(id) ON DELETE CASCADE" +
            ")"
        };

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(pragmaSql);
            for (String sql : createSqls) {
                stmt.execute(sql);
            }
        } catch (SQLException e) {
            LOGGER.severe("Database initialization failed: " + e.getMessage());
            throw new RuntimeException("Failed to initialize database", e);
        }
    }

    public void addProfile(Profile profile) {
        String sql = "INSERT INTO profils(photo, nom, prenom, naissance, age, nationalite, derniere_visite_medicale, " +
                     "email, telephone, github, linkedin, bio, annees_experience, niveau, disponible) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            setProfileStatement(pstmt, profile);
            pstmt.executeUpdate();

            try (ResultSet rs = pstmt.getGeneratedKeys()) {
                if (rs.next()) {
                    profile.setId(rs.getInt(1));
                    addCompetences(profile);
                    addLangues(profile);
                }
            }
        } catch (SQLException e) {
            LOGGER.warning("Failed to add profile: " + e.getMessage());
            throw new RuntimeException("Error adding profile", e);
        }
    }

    private void setProfileStatement(PreparedStatement pstmt, Profile profile) throws SQLException {
        pstmt.setString(1, profile.getPhotoPath());
        pstmt.setString(2, profile.getNom());
        pstmt.setString(3, profile.getPrenom());
        pstmt.setString(4, profile.getNaissance() != null ? profile.getNaissance().toString() : null);
        pstmt.setInt(5, profile.getAge());
        pstmt.setString(6, profile.getNationalite());
        pstmt.setString(7, profile.getDerniereVisiteMedicale() != null ? profile.getDerniereVisiteMedicale().toString() : null);
        pstmt.setString(8, profile.getEmail());
        pstmt.setString(9, profile.getTelephone());
        pstmt.setString(10, profile.getGithub());
        pstmt.setString(11, profile.getLinkedin());
        pstmt.setString(12, profile.getBio());
        pstmt.setInt(13, profile.getAnneesExperience());
        pstmt.setString(14, profile.getNiveau());
        pstmt.setBoolean(15, profile.isDisponible());
    }

    private void addCompetences(Profile profile) throws SQLException {
        if (profile.getCompetences().isEmpty()) return;

        String sql = "INSERT INTO competences(profil_id, technologie, niveau) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            for (String competence : profile.getCompetences()) {
                pstmt.setInt(1, profile.getId());
                pstmt.setString(2, competence);
                pstmt.setInt(3, 3); // Default level
                pstmt.addBatch();
            }
            pstmt.executeBatch();
        }
    }

    private void addLangues(Profile profile) throws SQLException {
        if (profile.getLangues().isEmpty()) return;

        String sql = "INSERT INTO langues(profil_id, langue, niveau) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            for (String langue : profile.getLangues()) {
                pstmt.setInt(1, profile.getId());
                pstmt.setString(2, langue);
                pstmt.setString(3, "Intermédiaire"); // Default level
                pstmt.addBatch();
            }
            pstmt.executeBatch();
        }
    }

    public List<Profile> getAllProfiles() {
        List<Profile> profiles = new ArrayList<>();
        String sql = "SELECT p.*, " +
                     "GROUP_CONCAT(DISTINCT c.technologie) AS competences, " +
                     "GROUP_CONCAT(DISTINCT l.langue) AS langues " +
                     "FROM profils p " +
                     "LEFT JOIN competences c ON p.id = c.profil_id " +
                     "LEFT JOIN langues l ON p.id = l.profil_id " +
                     "GROUP BY p.id";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                profiles.add(createProfileFromResultSet(rs));
            }
        } catch (SQLException e) {
            LOGGER.warning("Failed to retrieve profiles: " + e.getMessage());
            throw new RuntimeException("Error retrieving profiles", e);
        }
        return profiles;
    }

    private Profile createProfileFromResultSet(ResultSet rs) throws SQLException {
        Profile p = new Profile();
        p.setId(rs.getInt("id"));
        p.setPhotoPath(rs.getString("photo"));
        p.setNom(rs.getString("nom"));
        p.setPrenom(rs.getString("prenom"));

        String date = rs.getString("naissance");
        if (date != null) p.setNaissance(LocalDate.parse(date));

        p.setAge(rs.getInt("age"));
        p.setNationalite(rs.getString("nationalite"));

        String visiteMedicale = rs.getString("derniere_visite_medicale");
        if (visiteMedicale != null) p.setDerniereVisiteMedicale(LocalDate.parse(visiteMedicale));

        p.setEmail(rs.getString("email"));
        p.setTelephone(rs.getString("telephone"));
        p.setGithub(rs.getString("github"));
        p.setLinkedin(rs.getString("linkedin"));
        p.setBio(rs.getString("bio"));
        p.setAnneesExperience(rs.getInt("annees_experience"));
        p.setNiveau(rs.getString("niveau"));
        p.setDisponible(rs.getBoolean("disponible"));

        String competences = rs.getString("competences");
        if (competences != null) p.setCompetences(List.of(competences.split(",")));

        String langues = rs.getString("langues");
        if (langues != null) p.setLangues(List.of(langues.split(",")));

        return p;
    }

    public void updateProfile(Profile profile) {
        String sql = "UPDATE profils SET photo = ?, nom = ?, prenom = ?, naissance = ?, age = ?, nationalite = ?, " +
                     "derniere_visite_medicale = ?, email = ?, telephone = ?, github = ?, linkedin = ?, bio = ?, " +
                     "annees_experience = ?, niveau = ?, disponible = ? WHERE id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            setProfileStatement(pstmt, profile);
            pstmt.setInt(16, profile.getId());
            pstmt.executeUpdate();

            updateCompetences(profile);
            updateLangues(profile);
        } catch (SQLException e) {
            LOGGER.warning("Failed to update profile: " + e.getMessage());
            throw new RuntimeException("Error updating profile", e);
        }
    }

    private void updateCompetences(Profile profile) throws SQLException {
        try (PreparedStatement deleteStmt = conn.prepareStatement("DELETE FROM competences WHERE profil_id = ?")) {
            deleteStmt.setInt(1, profile.getId());
            deleteStmt.executeUpdate();
        }
        addCompetences(profile);
    }

    private void updateLangues(Profile profile) throws SQLException {
        try (PreparedStatement deleteStmt = conn.prepareStatement("DELETE FROM langues WHERE profil_id = ?")) {
            deleteStmt.setInt(1, profile.getId());
            deleteStmt.executeUpdate();
        }
        addLangues(profile);
    }

    public void deleteProfile(int id) {
        try (PreparedStatement pstmt = conn.prepareStatement("DELETE FROM profils WHERE id = ?")) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.warning("Failed to delete profile: " + e.getMessage());
            throw new RuntimeException("Error deleting profile", e);
        }
    }

    public void close() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException e) {
            LOGGER.warning("Failed to close database connection: " + e.getMessage());
        }
    }
}