import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import javax.imageio.ImageIO;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.util.logging.Logger;

public class AppUI extends JFrame {
    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = Logger.getLogger(AppUI.class.getName());
    private static final String APP_TITLE = "Profile Manager Premium";
    
    // Updated color scheme
    private static final Color PRIMARY_COLOR = new Color(25, 118, 210); // Material Blue #1976D2
    private static final Color PRIMARY_LIGHT = new Color(66, 165, 245); // Lighter Blue #42A5F5
    private static final Color SECONDARY_COLOR = new Color(216, 27, 96); // Material Pink #D81B60
    private static final Color BACKGROUND_COLOR = new Color(245, 247, 250); // Softer Light Gray #F5F7FA
    private static final Color FORM_BACKGROUND = new Color(250, 250, 250); // Soft White #FAFAFA
    private static final Color TEXT_COLOR = new Color(33, 33, 33); // Dark Gray #212121
    private static final Color LABEL_COLOR = new Color(66, 66, 66); // Darker Gray #424242
    private static final Color TABLE_ALT_ROW_COLOR = new Color(249, 250, 251); // #F9FAFB
    
    private Database db;
    private List<Profile> profiles;
    private DefaultTableModel tableModel;
    private JTable profilesTable;
    private JTextField searchField;
    private JTextField photoPathField;

    public AppUI() {
        super(APP_TITLE);
        db = new Database();
        profiles = db.getAllProfiles();
        initUI();
        loadProfiles();
    }

    private void initUI() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            customizeUIManager();
        } catch (Exception e) {
            LOGGER.severe("Failed to set look and feel: " + e.getMessage());
        }

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 800); // Légèrement agrandi pour mieux afficher les colonnes
        setLocationRelativeTo(null);
        setUndecorated(true);

        JPanel mainPanel = createMainPanel();
        setContentPane(mainPanel);
        addFadeInAnimation();
    }

    private void customizeUIManager() {
        UIManager.put("Label.font", new Font("Segoe UI", Font.PLAIN, 15));
        UIManager.put("TextField.font", new Font("Segoe UI", Font.PLAIN, 14));
        UIManager.put("Button.font", new Font("Segoe UI", Font.BOLD, 14));
        UIManager.put("Table.font", new Font("Segoe UI", Font.PLAIN, 14));
        UIManager.put("TableHeader.font", new Font("Segoe UI", Font.BOLD, 14));
    }

    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            private static final long serialVersionUID = 1L;
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(BACKGROUND_COLOR);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setOpaque(false);

        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);
        mainPanel.add(createTablePanel(), BorderLayout.CENTER);
        mainPanel.add(createToolPanel(), BorderLayout.SOUTH);
        return mainPanel;
    }

    private void addFadeInAnimation() {
        setOpacity(0.0f);
        Timer timer = new Timer(50, new ActionListener() {
            float opacity = 0.0f;

            @Override
            public void actionPerformed(ActionEvent e) {
                opacity += 0.1f;
                setOpacity(Math.min(1.0f, opacity));
                if (opacity >= 1.0f) {
                    ((Timer) e.getSource()).stop();
                }
            }
        });
        timer.start();
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout()) {
            private static final long serialVersionUID = 1L;
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gradient = new GradientPaint(
                        0, 0, PRIMARY_COLOR,
                        0, getHeight(), PRIMARY_LIGHT);
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setBorder(new EmptyBorder(10, 20, 10, 20));
        panel.setOpaque(false);

        JLabel appLabel = new JLabel(APP_TITLE);
        appLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        appLabel.setForeground(Color.WHITE);

        JPanel searchPanel = createSearchPanel();
        JButton closeBtn = createCloseButton();

        panel.add(appLabel, BorderLayout.WEST);
        panel.add(searchPanel, BorderLayout.CENTER);
        panel.add(closeBtn, BorderLayout.EAST);
        return panel;
    }

    private JPanel createSearchPanel() {
        JPanel searchPanel = new JPanel(new BorderLayout(10, 0));
        searchPanel.setOpaque(false);

        searchField = new JTextField();
        searchField.setPreferredSize(new Dimension(250, 32));
        searchField.setBorder(new CompoundBorder(
                new LineBorder(new Color(200, 200, 200), 1, true),
                new EmptyBorder(5, 10, 5, 10)));
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        searchField.setForeground(TEXT_COLOR);
        searchField.setBackground(Color.WHITE);
        searchField.setToolTipText("Rechercher par nom, prénom, email, nationalité, etc.");

        JLabel searchIcon = new JLabel("🔍");
        searchIcon.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        JPanel searchWrapper = new JPanel(new BorderLayout());
        searchWrapper.setOpaque(false);
        searchWrapper.setBorder(new EmptyBorder(0, 0, 0, 8));
        searchWrapper.add(searchIcon, BorderLayout.WEST);
        searchWrapper.add(searchField, BorderLayout.CENTER);

        JButton searchBtn = createStyledButton("Rechercher", PRIMARY_COLOR);
        searchBtn.addActionListener(e -> searchProfiles());

        searchPanel.add(searchWrapper, BorderLayout.CENTER);
        searchPanel.add(searchBtn, BorderLayout.EAST);
        return searchPanel;
    }

    private JButton createCloseButton() {
        JButton closeBtn = new JButton("×");
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 24));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setBackground(SECONDARY_COLOR);
        closeBtn.setOpaque(true);
        closeBtn.setBorder(new LineBorder(SECONDARY_COLOR, 2, true));
        closeBtn.setFocusPainted(false);
        closeBtn.setPreferredSize(new Dimension(40, 40));
        closeBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        closeBtn.setToolTipText("Fermer l'application");

        closeBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                closeBtn.setBackground(SECONDARY_COLOR.brighter());
                closeBtn.setBorder(new LineBorder(SECONDARY_COLOR.brighter(), 2, true));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                closeBtn.setBackground(SECONDARY_COLOR);
                closeBtn.setBorder(new LineBorder(SECONDARY_COLOR, 2, true));
            }
        });

        closeBtn.addActionListener(e -> System.exit(0));
        return closeBtn;
    }

    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            new EmptyBorder(10, 10, 10, 10)
        ));

        String[] columns = {
                "Nom", "Prénom", "Date de naissance", "Âge", "Nationalité", "Dernière visite médicale",
                "Années d'expérience", "Email", "Téléphone", "GitHub", "LinkedIn", "Bio", "Niveau",
                "Disponible", "Compétences", "Langues", "Photo"
        };
        tableModel = new DefaultTableModel(columns, 0) {
            private static final long serialVersionUID = 1L;
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int column) {
                if (column == 13) return Boolean.class;
                if (column == 16) return ImageIcon.class;
                return Object.class;
            }
        };

        profilesTable = new JTable(tableModel) {
            private static final long serialVersionUID = 1L;
        };
        profilesTable.setRowHeight(40);
        profilesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        profilesTable.setShowGrid(true);
        profilesTable.setGridColor(new Color(220, 220, 220));
        profilesTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        profilesTable.setForeground(TEXT_COLOR);
        profilesTable.setIntercellSpacing(new Dimension(0, 0));

        profilesTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            private static final long serialVersionUID = 1L;
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                JLabel label = (JLabel) c;
                label.setToolTipText(value != null ? value.toString() : "");

                if (isSelected) {
                    JPanel panel = new JPanel() {
                        private static final long serialVersionUID = 1L;
                        @Override
                        protected void paintComponent(Graphics g) {
                            super.paintComponent(g);
                            Graphics2D g2d = (Graphics2D) g;
                            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                            GradientPaint gradient = new GradientPaint(
                                    0, 0, PRIMARY_LIGHT,
                                    0, getHeight(), new Color(100, 181, 246));
                            g2d.setPaint(gradient);
                            g2d.fillRect(0, 0, getWidth(), getHeight());
                        }
                    };
                    panel.setOpaque(false);
                    label.setOpaque(false);
                    label.setForeground(Color.WHITE);
                    label.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                    panel.add(label);
                    return panel;
                } else {
                    label.setBackground(row % 2 == 0 ? Color.WHITE : TABLE_ALT_ROW_COLOR);
                    label.setForeground(TEXT_COLOR);
                    label.setOpaque(true);
                    label.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                    return label;
                }
            }
        });

        profilesTable.setDefaultRenderer(Boolean.class, new DefaultTableCellRenderer() {
            private static final long serialVersionUID = 1L;
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                JCheckBox checkBox = new JCheckBox();
                checkBox.setSelected(value != null && (Boolean) value);
                checkBox.setHorizontalAlignment(SwingConstants.CENTER);

                if (isSelected) {
                    JPanel panel = new JPanel() {
                        private static final long serialVersionUID = 1L;
                        @Override
                        protected void paintComponent(Graphics g) {
                            super.paintComponent(g);
                            Graphics2D g2d = (Graphics2D) g;
                            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                            GradientPaint gradient = new GradientPaint(
                                    0, 0, PRIMARY_LIGHT,
                                    0, getHeight(), new Color(100, 181, 246));
                            g2d.setPaint(gradient);
                            g2d.fillRect(0, 0, getWidth(), getHeight());
                        }
                    };
                    panel.setOpaque(false);
                    checkBox.setOpaque(false);
                    checkBox.setForeground(Color.WHITE);
                    panel.add(checkBox);
                    return panel;
                } else {
                    checkBox.setBackground(row % 2 == 0 ? Color.WHITE : TABLE_ALT_ROW_COLOR);
                    checkBox.setOpaque(true);
                    return checkBox;
                }
            }
        });

        profilesTable.setDefaultRenderer(ImageIcon.class, new DefaultTableCellRenderer() {
            private static final long serialVersionUID = 1L;
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                JLabel label = new JLabel((ImageIcon) value);
                label.setHorizontalAlignment(SwingConstants.CENTER);

                if (isSelected) {
                    JPanel panel = new JPanel() {
                        private static final long serialVersionUID = 1L;
                        @Override
                        protected void paintComponent(Graphics g) {
                            super.paintComponent(g);
                            Graphics2D g2d = (Graphics2D) g;
                            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                            GradientPaint gradient = new GradientPaint(
                                    0, 0, PRIMARY_LIGHT,
                                    0, getHeight(), new Color(100, 181, 246));
                            g2d.setPaint(gradient);
                            g2d.fillRect(0, 0, getWidth(), getHeight());
                        }
                    };
                    panel.setOpaque(false);
                    label.setOpaque(false);
                    label.setForeground(Color.WHITE);
                    panel.add(label);
                    return panel;
                } else {
                    label.setBackground(row % 2 == 0 ? Color.WHITE : TABLE_ALT_ROW_COLOR);
                    label.setOpaque(true);
                    return label;
                }
            }
        });

        profilesTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = profilesTable.getSelectedRow();
                    if (row >= 0) {
                        Profile profile = findProfileByRow(row);
                        if (profile != null) {
                            showProfileDetails(profile);
                        }
                    }
                }
            }
        });

        profilesTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        for (int i = 0; i < columns.length; i++) {
            TableColumn column = profilesTable.getColumnModel().getColumn(i);
            column.setPreferredWidth(i == 16 ? 60 : i == 13 ? 100 : 150); // Ajustement des largeurs
        }

        JTableHeader header = profilesTable.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(240, 240, 240));
        header.setForeground(TEXT_COLOR);
        header.setBorder(new EmptyBorder(8, 8, 8, 8));

        JScrollPane scrollPane = new JScrollPane(profilesTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(Color.WHITE);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createToolPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(10, 0, 0, 0));

        JButton addBtn = createStyledButton("Ajouter", new Color(40, 167, 69));
        JButton editBtn = createStyledButton("Modifier", new Color(255, 152, 0));
        JButton deleteBtn = createStyledButton("Supprimer", SECONDARY_COLOR);
        JButton refreshBtn = createStyledButton("Actualiser", new Color(111, 66, 193));

        Dimension btnSize = new Dimension(120, 40);
        addBtn.setPreferredSize(btnSize);
        editBtn.setPreferredSize(btnSize);
        deleteBtn.setPreferredSize(btnSize);
        refreshBtn.setPreferredSize(btnSize);

        addBtn.addActionListener(e -> showProfileForm(null));
        editBtn.addActionListener(e -> editSelectedProfile());
        deleteBtn.addActionListener(e -> deleteSelectedProfile());
        refreshBtn.addActionListener(e -> refreshProfiles());

        panel.add(addBtn);
        panel.add(editBtn);
        panel.add(deleteBtn);
        panel.add(refreshBtn);
        return panel;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setForeground(Color.BLACK);
        btn.setBackground(bgColor);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(bgColor.darker(), 1, true),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(bgColor.brighter());
                btn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(bgColor.brighter(), 1, true),
                    BorderFactory.createEmptyBorder(8, 15, 8, 15)
                ));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bgColor);
                btn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(bgColor.darker(), 1, true),
                    BorderFactory.createEmptyBorder(8, 15, 8, 15)
                ));
            }
        });
        return btn;
    }

    private void loadProfiles() {
        tableModel.setRowCount(0);
        for (Profile profile : profiles) {
            ImageIcon photoIcon = loadProfileImage(profile);
            tableModel.addRow(new Object[]{
                    profile.getNom(),
                    profile.getPrenom(),
                    profile.getNaissance() != null ? profile.getNaissance().toString() : "",
                    profile.getAge(),
                    profile.getNationalite(),
                    profile.getDerniereVisiteMedicale() != null ? profile.getDerniereVisiteMedicale().toString() : "",
                    profile.getAnneesExperience(),
                    profile.getEmail(),
                    profile.getTelephone(),
                    profile.getGithub(),
                    profile.getLinkedin(),
                    profile.getBio(),
                    profile.getNiveau(),
                    profile.isDisponible(),
                    String.join(", ", profile.getCompetences()),
                    String.join(", ", profile.getLangues()),
                    photoIcon
            });
        }
    }

    private ImageIcon loadProfileImage(Profile profile) {
        String photoPath = profile.getPhotoPath();
        if (photoPath != null && !photoPath.isEmpty()) {
            try {
                File imageFile = new File(photoPath);
                if (imageFile.exists()) {
                    BufferedImage img = ImageIO.read(imageFile);
                    Image scaledImg = img.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
                    return new ImageIcon(scaledImg);
                }
            } catch (Exception e) {
                LOGGER.warning("Failed to load image for profile " + profile.getNom() + ": " + e.getMessage());
            }
        }
        return new ImageIcon(createDefaultPhoto(profile.getNom(), profile.getPrenom()));
    }

    private Image createDefaultPhoto(String nom, String prenom) {
        nom = nom != null && !nom.isEmpty() ? nom : " ";
        prenom = prenom != null && !prenom.isEmpty() ? prenom : " ";

        BufferedImage img = new BufferedImage(30, 30, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = img.createGraphics();

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(PRIMARY_COLOR);
        g2d.fillOval(0, 0, 30, 30);

        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 12));
        String initials = (nom.charAt(0) + "" + prenom.charAt(0)).toUpperCase();

        FontMetrics fm = g2d.getFontMetrics();
        int x = (30 - fm.stringWidth(initials)) / 2;
        int y = ((30 - fm.getHeight()) / 2) + fm.getAscent();

        g2d.drawString(initials, x, y);
        g2d.dispose();
        return img;
    }

    private void searchProfiles() {
        String searchText = searchField.getText().toLowerCase().trim();
        List<Profile> filteredProfiles = profiles.stream()
                .filter(p -> p.getNom().toLowerCase().contains(searchText) ||
                        p.getPrenom().toLowerCase().contains(searchText) ||
                        p.getEmail().toLowerCase().contains(searchText) ||
                        p.getTelephone().toLowerCase().contains(searchText) ||
                        p.getGithub().toLowerCase().contains(searchText) ||
                        p.getLinkedin().toLowerCase().contains(searchText) ||
                        p.getBio().toLowerCase().contains(searchText) ||
                        p.getNationalite().toLowerCase().contains(searchText))
                .collect(Collectors.toList());

        tableModel.setRowCount(0);
        for (Profile profile : filteredProfiles) {
            ImageIcon photoIcon = loadProfileImage(profile);
            tableModel.addRow(new Object[]{
                    profile.getNom(),
                    profile.getPrenom(),
                    profile.getNaissance() != null ? profile.getNaissance().toString() : "",
                    profile.getAge(),
                    profile.getNationalite(),
                    profile.getDerniereVisiteMedicale() != null ? profile.getDerniereVisiteMedicale().toString() : "",
                    profile.getAnneesExperience(),
                    profile.getEmail(),
                    profile.getTelephone(),
                    profile.getGithub(),
                    profile.getLinkedin(),
                    profile.getBio(),
                    profile.getNiveau(),
                    profile.isDisponible(),
                    String.join(", ", profile.getCompetences()),
                    String.join(", ", profile.getLangues()),
                    photoIcon
            });
        }
    }

    private void refreshProfiles() {
        profiles = db.getAllProfiles();
        loadProfiles();
        searchField.setText("");
    }

    private void showProfileForm(Profile profile) {
        JDialog dialog = new JDialog(this, profile == null ? "Nouveau Profil" : "Modifier Profil", true);
        dialog.setSize(750, 650); // Légèrement agrandi pour les nouveaux champs
        dialog.setLocationRelativeTo(this);
        dialog.setUndecorated(true);

        JPanel mainPanel = new JPanel(new BorderLayout()) {
            private static final long serialVersionUID = 1L;
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(FORM_BACKGROUND);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2d.setColor(new Color(0, 0, 0, 30));
                g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
            }
        };
        mainPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0, 0, 0, 20), 1),
            new EmptyBorder(20, 20, 20, 20)));
        mainPanel.setOpaque(false);

        JPanel headerPanel = new JPanel(new BorderLayout()) {
            private static final long serialVersionUID = 1L;
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gradient = new GradientPaint(
                        0, 0, PRIMARY_COLOR,
                        0, getHeight(), PRIMARY_LIGHT);
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        headerPanel.setOpaque(false);
        headerPanel.setBorder(new EmptyBorder(10, 15, 10, 15));

        JLabel title = new JLabel(profile == null ? "Nouveau Profil" : "Modifier Profil");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);

        JButton closeBtn = new JButton("×");
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 24));
        closeBtn.setContentAreaFilled(false);
        closeBtn.setBorderPainted(false);
        closeBtn.setForeground(Color.WHITE);
        closeBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                closeBtn.setForeground(SECONDARY_COLOR.brighter());
            }

            @Override
            public void mouseExited(MouseEvent e) {
                closeBtn.setForeground(Color.WHITE);
            }
        });
        closeBtn.addActionListener(e -> dialog.dispose());

        headerPanel.add(title, BorderLayout.WEST);
        headerPanel.add(closeBtn, BorderLayout.EAST);

        JPanel formPanel = new JPanel(new GridLayout(0, 2, 20, 20));
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 10, 20, 10));

        JTextField nomField = createTextField(profile != null ? profile.getNom() : "");
        JTextField prenomField = createTextField(profile != null ? profile.getPrenom() : "");
        JTextField emailField = createTextField(profile != null ? profile.getEmail() : "");
        JTextField telephoneField = createTextField(profile != null ? profile.getTelephone() : "");
        JTextField githubField = createTextField(profile != null ? profile.getGithub() : "");
        JTextField linkedinField = createTextField(profile != null ? profile.getLinkedin() : "");
        JTextField bioField = createTextField(profile != null ? profile.getBio() : "");
        JTextField ageField = createTextField(profile != null ? String.valueOf(profile.getAge()) : "");
        JTextField nationaliteField = createTextField(profile != null ? profile.getNationalite() : "");
        JTextField anneesExperienceField = createTextField(profile != null ? String.valueOf(profile.getAnneesExperience()) : "0");
        JTextField competencesField = createTextField(profile != null ? String.join(", ", profile.getCompetences()) : "");
        JTextField languesField = createTextField(profile != null ? String.join(", ", profile.getLangues()) : "");
        photoPathField = createTextField(profile != null ? profile.getPhotoPath() : "");
        photoPathField.setEditable(false);

        JPanel dateNaissancePanel = createDatePanel(profile, true);
        JPanel visiteMedicalePanel = createDatePanel(profile, false);
        JButton choosePhotoBtn = createStyledButton("Choisir Photo", PRIMARY_COLOR);
        choosePhotoBtn.addActionListener(e -> choosePhoto(dialog));

        addFormField(formPanel, "Nom*:", nomField);
        addFormField(formPanel, "Prénom*:", prenomField);
        addFormField(formPanel, "Email*:", emailField);
        addFormField(formPanel, "Téléphone:", telephoneField);
        addFormField(formPanel, "GitHub:", githubField);
        addFormField(formPanel, "LinkedIn:", linkedinField);
        addFormField(formPanel, "Bio:", bioField);
        addFormField(formPanel, "Date de naissance:", dateNaissancePanel);
        addFormField(formPanel, "Âge:", ageField);
        addFormField(formPanel, "Nationalité:", nationaliteField);
        addFormField(formPanel, "Dernière visite médicale:", visiteMedicalePanel);
        addFormField(formPanel, "Années d'expérience:", anneesExperienceField);
        addFormField(formPanel, "Compétences (séparées par des virgules):", competencesField);
        addFormField(formPanel, "Langues (séparées par des virgules):", languesField);
        addFormField(formPanel, "Photo:", photoPathField);
        formPanel.add(new JLabel());
        formPanel.add(choosePhotoBtn);

        JComboBox<String> niveauCombo = new JComboBox<>(new String[]{"Junior", "Intermédiaire", "Senior"});
        if (profile != null) niveauCombo.setSelectedItem(profile.getNiveau());
        addFormField(formPanel, "Niveau:", niveauCombo);

        JCheckBox disponibleCheck = new JCheckBox();
        if (profile != null) disponibleCheck.setSelected(profile.isDisponible());
        addFormField(formPanel, "Disponible:", disponibleCheck);

        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footerPanel.setOpaque(false);
        JButton saveBtn = createStyledButton("Enregistrer", PRIMARY_COLOR);
        saveBtn.setPreferredSize(new Dimension(150, 40));
        saveBtn.addActionListener(e -> saveProfile(dialog, profile, nomField, prenomField, emailField,
                telephoneField, githubField, linkedinField, bioField, dateNaissancePanel,
                ageField, nationaliteField, visiteMedicalePanel, anneesExperienceField,
                competencesField, languesField, photoPathField, niveauCombo, disponibleCheck));

        footerPanel.add(saveBtn);

        JScrollPane scrollPane = new JScrollPane(formPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        dialog.add(mainPanel);
        dialog.setVisible(true);
    }

    private JTextField createTextField(String text) {
        JTextField field = new JTextField(text);
        field.setBorder(new CompoundBorder(
                new LineBorder(new Color(200, 200, 200), 1, true),
                new EmptyBorder(5, 10, 5, 10)));
        field.setForeground(TEXT_COLOR);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBackground(Color.WHITE);
        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                field.setBorder(new CompoundBorder(
                        new LineBorder(PRIMARY_COLOR, 1, true),
                        new EmptyBorder(5, 10, 5, 10)));
            }

            @Override
            public void focusLost(FocusEvent e) {
                field.setBorder(new CompoundBorder(
                        new LineBorder(new Color(200, 200, 200), 1, true),
                        new EmptyBorder(5, 10, 5, 10)));
            }
        });
        field.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (!field.hasFocus()) {
                    field.setBorder(new CompoundBorder(
                            new LineBorder(PRIMARY_LIGHT, 1, true),
                            new EmptyBorder(5, 10, 5, 10)));
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (!field.hasFocus()) {
                    field.setBorder(new CompoundBorder(
                            new LineBorder(new Color(200, 200, 200), 1, true),
                            new EmptyBorder(5, 10, 5, 10)));
                }
            }
        });
        return field;
    }

    private JPanel createDatePanel(Profile profile, boolean isNaissance) {
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        datePanel.setOpaque(false);

        JComboBox<String> dayCombo = new JComboBox<>();
        for (int i = 1; i <= 31; i++) dayCombo.addItem(String.format("%02d", i));
        JComboBox<String> monthCombo = new JComboBox<>();
        for (int i = 1; i <= 12; i++) monthCombo.addItem(String.format("%02d", i));
        JComboBox<String> yearCombo = new JComboBox<>();
        for (int i = LocalDate.now().getYear(); i >= 1900; i--) yearCombo.addItem(String.valueOf(i));

        if (profile != null) {
            LocalDate date = isNaissance ? profile.getNaissance() : profile.getDerniereVisiteMedicale();
            if (date != null) {
                dayCombo.setSelectedItem(String.format("%02d", date.getDayOfMonth()));
                monthCombo.setSelectedItem(String.format("%02d", date.getMonthValue()));
                yearCombo.setSelectedItem(String.valueOf(date.getYear()));
            }
        }

        datePanel.add(dayCombo);
        datePanel.add(new JLabel("/"));
        datePanel.add(monthCombo);
        datePanel.add(new JLabel("/"));
        datePanel.add(yearCombo);
        return datePanel;
    }

    private void choosePhoto(JDialog dialog) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("Image files", "jpg", "jpeg", "png", "gif"));
        if (fileChooser.showOpenDialog(dialog) == JFileChooser.APPROVE_OPTION) {
            photoPathField.setText(fileChooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void addFormField(JPanel panel, String label, JComponent field) {
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        lbl.setForeground(LABEL_COLOR);

        if (field instanceof JTextField || field instanceof JComboBox || field instanceof JPanel) {
            field.setPreferredSize(new Dimension(300, 32));
        }

        panel.add(lbl);
        panel.add(field);
    }

    private void saveProfile(JDialog dialog, Profile profile, JTextField nomField, JTextField prenomField,
                             JTextField emailField, JTextField telephoneField, JTextField githubField,
                             JTextField linkedinField, JTextField bioField, JPanel dateNaissancePanel,
                             JTextField ageField, JTextField nationaliteField, JPanel visiteMedicalePanel,
                             JTextField anneesExperienceField, JTextField competencesField,
                             JTextField languesField, JTextField photoPathField,
                             JComboBox<String> niveauCombo, JCheckBox disponibleCheck) {
        if (!validateForm(nomField, prenomField, emailField)) {
            return;
        }

        Profile updatedProfile = profile != null ? profile : new Profile();
        updateProfileFromFields(updatedProfile, nomField, prenomField, emailField,
                telephoneField, githubField, linkedinField, bioField, dateNaissancePanel,
                ageField, nationaliteField, visiteMedicalePanel, anneesExperienceField,
                competencesField, languesField, photoPathField, niveauCombo, disponibleCheck);

        if (profile == null) {
            db.addProfile(updatedProfile);
        } else {
            db.updateProfile(updatedProfile);
        }
        dialog.dispose();
        refreshProfiles();
    }

    private boolean validateForm(JTextField nomField, JTextField prenomField, JTextField emailField) {
        if (nomField.getText().trim().isEmpty() || prenomField.getText().trim().isEmpty() || emailField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Les champs Nom, Prénom et Email sont obligatoires",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (!emailField.getText().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            JOptionPane.showMessageDialog(this,
                    "Veuillez entrer un email valide",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private void updateProfileFromFields(Profile profile, JTextField nomField, JTextField prenomField,
                                         JTextField emailField, JTextField telephoneField, JTextField githubField,
                                         JTextField linkedinField, JTextField bioField, JPanel dateNaissancePanel,
                                         JTextField ageField, JTextField nationaliteField, JPanel visiteMedicalePanel,
                                         JTextField anneesExperienceField, JTextField competencesField,
                                         JTextField languesField, JTextField photoPathField,
                                         JComboBox<String> niveauCombo, JCheckBox disponibleCheck) {
        profile.setNom(nomField.getText().trim());
        profile.setPrenom(prenomField.getText().trim());
        profile.setEmail(emailField.getText().trim());
        profile.setTelephone(telephoneField.getText().trim());
        profile.setGithub(githubField.getText().trim());
        profile.setLinkedin(linkedinField.getText().trim());
        profile.setBio(bioField.getText().trim());
        profile.setPhotoPath(photoPathField.getText().trim());
        profile.setNiveau((String) niveauCombo.getSelectedItem());
        profile.setDisponible(disponibleCheck.isSelected());

        try {
            Component yearComp = dateNaissancePanel.getComponent(4);
            Component monthComp = dateNaissancePanel.getComponent(2);
            Component dayComp = dateNaissancePanel.getComponent(0);

            if (yearComp instanceof JComboBox && monthComp instanceof JComboBox && dayComp instanceof JComboBox) {
                @SuppressWarnings("unchecked")
                JComboBox<String> yearCombo = (JComboBox<String>) yearComp;
                @SuppressWarnings("unchecked")
                JComboBox<String> monthCombo = (JComboBox<String>) monthComp;
                @SuppressWarnings("unchecked")
                JComboBox<String> dayCombo = (JComboBox<String>) dayComp;

                String dateStr = yearCombo.getSelectedItem() + "-" + monthCombo.getSelectedItem() + "-" + dayCombo.getSelectedItem();
                profile.setNaissance(LocalDate.parse(dateStr));
            } else {
                profile.setNaissance(null);
            }
        } catch (Exception e) {
            profile.setNaissance(null);
        }

        try {
            Component yearComp = visiteMedicalePanel.getComponent(4);
            Component monthComp = visiteMedicalePanel.getComponent(2);
            Component dayComp = visiteMedicalePanel.getComponent(0);

            if (yearComp instanceof JComboBox && monthComp instanceof JComboBox && dayComp instanceof JComboBox) {
                @SuppressWarnings("unchecked")
                JComboBox<String> yearCombo = (JComboBox<String>) yearComp;
                @SuppressWarnings("unchecked")
                JComboBox<String> monthCombo = (JComboBox<String>) monthComp;
                @SuppressWarnings("unchecked")
                JComboBox<String> dayCombo = (JComboBox<String>) dayComp;

                String dateStr = yearCombo.getSelectedItem() + "-" + monthCombo.getSelectedItem() + "-" + dayCombo.getSelectedItem();
                profile.setDerniereVisiteMedicale(LocalDate.parse(dateStr));
            } else {
                profile.setDerniereVisiteMedicale(null);
            }
        } catch (Exception e) {
            profile.setDerniereVisiteMedicale(null);
        }

        try {
            profile.setAge(Integer.parseInt(ageField.getText().trim()));
        } catch (NumberFormatException e) {
            profile.setAge(0);
        }

        profile.setNationalite(nationaliteField.getText().trim());

        try {
            profile.setAnneesExperience(Integer.parseInt(anneesExperienceField.getText().trim()));
        } catch (NumberFormatException e) {
            profile.setAnneesExperience(0);
        }

        String competencesText = competencesField.getText().trim();
        profile.setCompetences(competencesText.isEmpty() ? new java.util.ArrayList<>() :
                List.of(competencesText.split("\\s*,\\s*")));

        String languesText = languesField.getText().trim();
        profile.setLangues(languesText.isEmpty() ? new java.util.ArrayList<>() :
                List.of(languesText.split("\\s*,\\s*")));
    }

    private void showProfileDetails(Profile profile) {
        JDialog dialog = new JDialog(this, "Détails du Profil", true);
        dialog.setSize(550, 700); // Légèrement agrandi pour les nouveaux champs
        dialog.setLocationRelativeTo(this);
        dialog.setUndecorated(true);

        JPanel mainPanel = new JPanel(new BorderLayout()) {
            private static final long serialVersionUID = 1L;
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(BACKGROUND_COLOR);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2d.setColor(new Color(0, 0, 0, 30));
                g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
            }
        };
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setOpaque(false);

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        headerPanel.setBorder(new EmptyBorder(0, 0, 20, 0));

        JLabel photoLabel = new JLabel(loadProfileImage(profile));
        photoLabel.setBorder(new EmptyBorder(0, 0, 0, 20));

        JLabel nameLabel = new JLabel(profile.getNom() + " " + profile.getPrenom());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        nameLabel.setForeground(PRIMARY_COLOR);

        JButton closeBtn = new JButton("×");
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 24));
        closeBtn.setContentAreaFilled(false);
        closeBtn.setBorderPainted(false);
        closeBtn.setForeground(SECONDARY_COLOR);
        closeBtn.addActionListener(e -> dialog.dispose());

        headerPanel.add(photoLabel, BorderLayout.WEST);
        headerPanel.add(nameLabel, BorderLayout.CENTER);
        headerPanel.add(closeBtn, BorderLayout.EAST);

        JPanel detailsPanel = new JPanel(new GridLayout(0, 1, 10, 10));
        detailsPanel.setOpaque(false);
        detailsPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        detailsPanel.setBackground(Color.WHITE);
        detailsPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            new EmptyBorder(15, 15, 15, 15)
        ));

        addDetailField(detailsPanel, "Date de naissance:", profile.getNaissance() != null ? profile.getNaissance().toString() : "Non spécifiée");
        addDetailField(detailsPanel, "Âge:", String.valueOf(profile.getAge()));
        addDetailField(detailsPanel, "Nationalité:", profile.getNationalite());
        addDetailField(detailsPanel, "Dernière visite médicale:", profile.getDerniereVisiteMedicale() != null ? profile.getDerniereVisiteMedicale().toString() : "Non spécifiée");
        addDetailField(detailsPanel, "Email:", profile.getEmail());
        addDetailField(detailsPanel, "Téléphone:", profile.getTelephone());
        addDetailField(detailsPanel, "GitHub:", profile.getGithub());
        addDetailField(detailsPanel, "LinkedIn:", profile.getLinkedin());
        addDetailField(detailsPanel, "Bio:", profile.getBio());
        addDetailField(detailsPanel, "Années d'expérience:", String.valueOf(profile.getAnneesExperience()));
        addDetailField(detailsPanel, "Niveau:", profile.getNiveau());
        addDetailField(detailsPanel, "Disponible:", profile.isDisponible() ? "Oui" : "Non");
        addDetailField(detailsPanel, "Compétences:", String.join(", ", profile.getCompetences()));
        addDetailField(detailsPanel, "Langues:", String.join(", ", profile.getLangues()));

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(new JScrollPane(detailsPanel), BorderLayout.CENTER);

        dialog.add(mainPanel);
        dialog.setVisible(true);
    }

    private void addDetailField(JPanel panel, String label, String value) {
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbl.setForeground(PRIMARY_COLOR);

        JTextArea valueArea = new JTextArea(value);
        valueArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        valueArea.setForeground(TEXT_COLOR);
        valueArea.setEditable(false);
        valueArea.setLineWrap(true);
        valueArea.setWrapStyleWord(true);
        valueArea.setOpaque(false);

        panel.add(lbl);
        panel.add(valueArea);
    }

    private void editSelectedProfile() {
        int row = profilesTable.getSelectedRow();
        if (row >= 0) {
            Profile profile = findProfileByRow(row);
            if (profile != null) {
                showProfileForm(profile);
            }
        } else {
            JOptionPane.showMessageDialog(this,
                    "Veuillez sélectionner un profil",
                    "Avertissement",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    private Profile findProfileByRow(int row) {
        String nom = (String) tableModel.getValueAt(row, 0);
        String prenom = (String) tableModel.getValueAt(row, 1);
        return profiles.stream()
                .filter(p -> p.getNom().equals(nom) && p.getPrenom().equals(prenom))
                .findFirst()
                .orElse(null);
    }

    private void deleteSelectedProfile() {
        int row = profilesTable.getSelectedRow();
        if (row >= 0) {
            Profile profile = findProfileByRow(row);
            if (profile != null) {
                int confirm = JOptionPane.showConfirmDialog(
                        this,
                        "Voulez-vous vraiment supprimer ce profil ?",
                        "Confirmation",
                        JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    db.deleteProfile(profile.getId());
                    refreshProfiles();
                }
            }
        } else {
            JOptionPane.showMessageDialog(this,
                    "Veuillez sélectionner un profil",
                    "Avertissement",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                AppUI app = new AppUI();
                app.setVisible(true);
            } catch (Exception e) {
                LOGGER.severe("Application startup failed: " + e.getMessage());
                JOptionPane.showMessageDialog(null,
                        "Erreur lors du démarrage de l'application",
                        "Erreur",
                        JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}